package com.example.javafxdemo.test;

import com.example.javafxdemo.data.CurrentData;
import com.example.javafxdemo.utils.ClassPath;
import com.example.javafxdemo.utils.PrintProgress;
import com.example.javafxdemo.utils.UserData;
import com.example.javafxdemo.utils.Utils;

import java.awt.*;
import java.io.IOException;

/**
 * use to test image insert in printing page
 */
public class ImageTest {
    /**
     * main entry of the test
     * @param args command line args
     * @throws IOException when there are any exceptions
     */
    public static void main(String[] args) throws IOException {
//        String backgroundPath = ClassPath.classPath+ "ticket.png";
//        String message = "John";
//        String outPutPath = ClassPath.classPath+ "user-ticket.png";
//
//        Utils.overlapImage(backgroundPath, message, outPutPath,87,169,22);
//
//
//        message = "AB1010";
//        Utils.overlapImage(outPutPath, message, outPutPath,91,194,22);
//
//
//        message = "Beijing";
//        Utils.overlapImage(outPutPath, message, outPutPath,85,121,22);
//
//        message = "Shanghai";
//        Utils.overlapImage(outPutPath, message, outPutPath,58,146,22);



    }
}
