package com.example.javafxdemo.controller;

/**
 * used to unite all controllers
 */
public interface Controller {
    /**
     * initialize the page
     */
    void init();
}
