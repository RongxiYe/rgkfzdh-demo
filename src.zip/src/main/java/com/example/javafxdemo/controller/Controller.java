package com.example.javafxdemo.controller;

public interface Controller {

    void init();
}
