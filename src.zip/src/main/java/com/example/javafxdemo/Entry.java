package com.example.javafxdemo;

import javafx.application.Application;
public class Entry {
    public static void main(String[] args) {
        Application.launch(HelloApplication.class, args);
    }
}

