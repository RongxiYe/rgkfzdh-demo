package com.example.javafxdemo.test;


import com.example.javafxdemo.utils.ClassPath;
import com.example.javafxdemo.utils.Utils;
import org.junit.Test;

import java.io.IOException;


public class ScanFileTest {
    @Test
    public void test() {


    }
}
